package com.example.a12imageview;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ImageView ugly = (ImageView)findViewById(R.id.imageView3);
        ugly.setImageDrawable(getResources().getDrawable(R.drawable.ugly));

    }
    public void button(View view) {
        ImageView ugly = (ImageView)findViewById(R.id.imageView3);
        ugly.setImageDrawable(getResources().getDrawable(R.drawable.cute));
    }
}